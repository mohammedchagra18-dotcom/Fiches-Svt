import { useState } from 'react';

// Types
interface Flashcard {
  term: string;
  definition: string;
}

interface QuizQuestion {
  question: string;
  options: string[];
  correct: number;
  explanation?: string;
}

// Data
const flashcards: Flashcard[] = [
  { term: "Métabolisme", definition: "Ensemble des réactions chimiques de dégradation et de synthèse dans une cellule" },
  { term: "Milieu Intérieur", definition: "Lymphe canalisée + lymphe interstitielle + plasma" },
  { term: "ATP", definition: "Adénosine Triphosphate : molécule stockant l'énergie chimique utilisable par la cellule" },
  { term: "Biosynthèse", definition: "Passage de molécules simples à des molécules complexes (protéines, lipides, glucides)" },
  { term: "Mitochondrie", definition: "Organite cellulaire siège de la respiration cellulaire et de la production d'ATP" },
  { term: "Déchets Azotés", definition: "Urée, acide urique et créatinine issus de la dégradation des acides aminés" },
  { term: "Respiration cellulaire", definition: "Processus de dégradation du glucose avec O₂ pour produire de l'ATP, du CO₂ et de l'H₂O" },
  { term: "Excrétion", definition: "Élimination des déchets du métabolisme par les reins (urée) et les poumons (CO₂)" },
];

const qcmQuestions: QuizQuestion[] = [
  {
    question: "Quel est le rôle principal de la mitochondrie ?",
    options: ["La photosynthèse", "La respiration cellulaire et production d'ATP", "La division cellulaire", "La synthèse des protéines"],
    correct: 1,
    explanation: "La mitochondrie est le siège de la respiration cellulaire où le glucose est oxydé pour produire de l'ATP."
  },
  {
    question: "Que produit la respiration cellulaire à partir du glucose ?",
    options: ["O₂ + H₂O", "CO₂ + O₂", "ATP + CO₂ + H₂O", "Glucose + O₂"],
    correct: 2,
    explanation: "La respiration cellulaire : Glucose + O₂ → CO₂ + H₂O + ATP"
  },
  {
    question: "Qu'est-ce que le milieu intérieur ?",
    options: ["Le cytoplasme des cellules", "Plasma + lymphe", "Le sang artériel uniquement", "L'eau intercellulaire"],
    correct: 1,
    explanation: "Le milieu intérieur comprend le plasma sanguin et la lymphe (canalisée + interstitielle)."
  },
  {
    question: "Combien d'énergie libère l'hydrolyse de l'ATP ?",
    options: ["3,5 Kcal", "7,3 Kcal", "10 Kcal", "15 Kcal"],
    correct: 1,
    explanation: "ATP + H₂O → ADP + P + 7,3 Kcal"
  },
  {
    question: "Où se forme le glycogène par biosynthèse ?",
    options: ["Dans les muscles uniquement", "Dans le foie et les muscles", "Dans le tissu adipeux", "Dans le sang"],
    correct: 1,
    explanation: "Le glycogène est synthétisé dans le foie et les muscles à partir du glucose."
  },
  {
    question: "Quels sont les déchets azotés éliminés par les reins ?",
    options: ["CO₂ et H₂O", "Glucose et protéines", "Urée, acide urique, créatinine", "O₂ et ATP"],
    correct: 2,
    explanation: "Les déchets azotés proviennent de la dégradation des acides aminés."
  },
  {
    question: "Quel organe élimine le CO₂ produit par la respiration ?",
    options: ["Les reins", "Le foie", "Les poumons", "La peau"],
    correct: 2,
    explanation: "Le CO₂ est éliminé par les poumons lors de l'expiration."
  },
  {
    question: "Que sont les triglycérides synthétisés par biosynthèse ?",
    options: ["Des protéines", "Des lipides de stockage", "Des glucides", "Des acides nucléiques"],
    correct: 1,
    explanation: "Les triglycérides sont des lipides stockés dans le tissu adipeux."
  },
  {
    question: "Dans la respiration cellulaire, l'oxydation du glucose produit de l'ATP. Quel pourcentage d'énergie est stocké ?",
    options: ["100%", "Environ 40%", "Environ 10%", "Environ 90%"],
    correct: 1,
    explanation: "Environ 40% de l'énergie est stockée en ATP, le reste est dissipé en chaleur."
  },
  {
    question: "Quel est le rôle des capillaires dans les échanges liquidiens ?",
    options: ["Produire de l'ATP", "Assurer les échanges entre sang et cellules", "Synthétiser des protéines", "Éliminer l'urée"],
    correct: 1,
    explanation: "Les capillaires sanguins permettent les échanges de nutriments et déchets avec les cellules."
  },
];

// Mini-quiz questions
const miniQuizzes = {
  lymphe: {
    question: "D'où vient la lymphe interstitielle ?",
    options: ["Du cœur", "Du plasma sanguin qui traverse les capillaires", "Du système digestif", "Des poumons"],
    correct: 1
  },
  mitochondrie: {
    question: "Quel est l'organite siège de la respiration cellulaire ?",
    options: ["Le noyau", "Le ribosome", "La mitochondrie", "L'appareil de Golgi"],
    correct: 2
  }
};

// Flashcard Component
function FlashcardItem({ card, isFlipped, onClick }: { card: Flashcard; isFlipped: boolean; onClick: () => void }) {
  return (
    <div 
      className="relative h-40 w-full cursor-pointer perspective-1000"
      onClick={onClick}
    >
      <div className={`absolute inset-0 transition-transform duration-500 transform-style-preserve-3d ${isFlipped ? 'rotate-y-180' : ''}`}>
        {/* Front */}
        <div className="absolute inset-0 backface-hidden rounded-xl bg-gradient-to-br from-violet-500 to-indigo-600 p-4 flex items-center justify-center shadow-lg">
          <h3 className="text-xl font-bold text-white text-center">{card.term}</h3>
        </div>
        {/* Back */}
        <div className="absolute inset-0 backface-hidden rotate-y-180 rounded-xl bg-white border-2 border-violet-300 p-4 flex items-center justify-center shadow-lg">
          <p className="text-slate-700 text-center text-sm">{card.definition}</p>
        </div>
      </div>
    </div>
  );
}

// QCM Component
function QCMSection({ questions }: { questions: QuizQuestion[] }) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState<boolean[]>(new Array(questions.length).fill(false));

  const handleAnswer = (index: number) => {
    if (showResult) return;
    setSelectedAnswer(index);
    setShowResult(true);
    if (index === questions[currentQuestion].correct) {
      setScore(score + 1);
    }
    const newAnswered = [...answered];
    newAnswered[currentQuestion] = true;
    setAnswered(newAnswered);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  };

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
      setSelectedAnswer(null);
      setShowResult(false);
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowResult(false);
    setScore(0);
    setAnswered(new Array(questions.length).fill(false));
  };

  const isQuizComplete = answered.every(a => a);

  return (
    <div className="bg-white rounded-2xl p-6 shadow-xl border border-violet-100">
      {isQuizComplete ? (
        <div className="text-center py-8">
          <div className="text-6xl mb-4">🎉</div>
          <h3 className="text-2xl font-bold text-violet-700 mb-2">Quiz terminé !</h3>
          <p className="text-4xl font-bold text-indigo-600 mb-4">{score}/{questions.length}</p>
          <p className="text-slate-600 mb-6">
            {score === questions.length ? "Parfait ! Excellent travail !" : 
             score >= questions.length * 0.7 ? "Très bien ! Continue comme ça !" :
             "Continue à réviser, tu progresses !"}
          </p>
          <button 
            onClick={resetQuiz}
            className="px-6 py-3 bg-gradient-to-r from-violet-500 to-indigo-600 text-white rounded-xl font-semibold hover:shadow-lg transition-all"
          >
            Recommencer
          </button>
        </div>
      ) : (
        <>
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm font-medium text-violet-600">Question {currentQuestion + 1}/{questions.length}</span>
            <span className="text-sm font-medium text-indigo-600">Score: {score}</span>
          </div>
          <div className="w-full bg-violet-100 rounded-full h-2 mb-6">
            <div 
              className="bg-gradient-to-r from-violet-500 to-indigo-600 h-2 rounded-full transition-all"
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            />
          </div>
          <h4 className="text-lg font-semibold text-slate-800 mb-4">{questions[currentQuestion].question}</h4>
          <div className="space-y-3">
            {questions[currentQuestion].options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswer(index)}
                disabled={showResult}
                className={`w-full p-4 rounded-xl text-left transition-all ${
                  showResult
                    ? index === questions[currentQuestion].correct
                      ? 'bg-green-100 border-2 border-green-500 text-green-700'
                      : index === selectedAnswer
                        ? 'bg-red-100 border-2 border-red-500 text-red-700'
                        : 'bg-slate-50 text-slate-500'
                    : selectedAnswer === index
                      ? 'bg-violet-100 border-2 border-violet-500'
                      : 'bg-slate-50 hover:bg-violet-50 border-2 border-transparent'
                }`}
              >
                <span className="font-medium">{String.fromCharCode(65 + index)}.</span> {option}
              </button>
            ))}
          </div>
          {showResult && questions[currentQuestion].explanation && (
            <div className="mt-4 p-4 bg-indigo-50 rounded-xl border border-indigo-200">
              <p className="text-sm text-indigo-700">💡 {questions[currentQuestion].explanation}</p>
            </div>
          )}
          <div className="flex justify-between mt-6">
            <button 
              onClick={prevQuestion}
              disabled={currentQuestion === 0}
              className="px-4 py-2 rounded-xl bg-slate-100 text-slate-600 disabled:opacity-50 hover:bg-slate-200 transition-all"
            >
              ← Précédent
            </button>
            <button 
              onClick={nextQuestion}
              disabled={currentQuestion === questions.length - 1}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-violet-500 to-indigo-600 text-white disabled:opacity-50 hover:shadow-lg transition-all"
            >
              Suivant →
            </button>
          </div>
        </>
      )}
    </div>
  );
}

// Mini Quiz Component
function MiniQuiz({ quizData }: { quizData: { question: string; options: string[]; correct: number } }) {
  const [selected, setSelected] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleSelect = (index: number) => {
    if (showResult) return;
    setSelected(index);
    setShowResult(true);
  };

  const reset = () => {
    setSelected(null);
    setShowResult(false);
  };

  return (
    <div className="bg-indigo-50 rounded-xl p-4 border border-indigo-200">
      <p className="font-medium text-indigo-800 mb-3">❓ {quizData.question}</p>
      <div className="space-y-2">
        {quizData.options.map((option, index) => (
          <button
            key={index}
            onClick={() => handleSelect(index)}
            disabled={showResult}
            className={`w-full p-3 rounded-lg text-left text-sm transition-all ${
              showResult
                ? index === quizData.correct
                  ? 'bg-green-200 text-green-800'
                  : index === selected
                    ? 'bg-red-200 text-red-800'
                    : 'bg-white text-slate-500'
                : 'bg-white hover:bg-violet-100'
            }`}
          >
            {option}
          </button>
        ))}
      </div>
      {showResult && (
        <button 
          onClick={reset}
          className="mt-3 text-sm text-violet-600 hover:text-violet-800 font-medium"
        >
          Réessayer ↺
        </button>
      )}
    </div>
  );
}

// ATP Cycle Animation
function ATPCycle() {
  const [isHydrolyzed, setIsHydrolyzed] = useState(false);

  return (
    <div className="bg-gradient-to-br from-amber-50 to-orange-50 rounded-xl p-6 border border-amber-200">
      <h4 className="text-lg font-bold text-amber-800 mb-4 text-center">⚡ Cycle de l'ATP</h4>
      <div className="flex items-center justify-center gap-4">
        <div 
          onClick={() => setIsHydrolyzed(false)}
          className={`cursor-pointer p-4 rounded-xl transition-all ${!isHydrolyzed ? 'bg-gradient-to-br from-violet-500 to-indigo-600 text-white scale-110 shadow-lg' : 'bg-white text-slate-600 border border-slate-200'}`}
        >
          <div className="text-center">
            <div className="text-2xl mb-1">🔋</div>
            <div className="font-bold">ATP</div>
            <div className="text-xs opacity-80">(chargé)</div>
          </div>
        </div>
        
        <button 
          onClick={() => setIsHydrolyzed(!isHydrolyzed)}
          className="px-4 py-2 bg-amber-500 text-white rounded-lg font-bold hover:bg-amber-600 transition-all"
        >
          {isHydrolyzed ? '← Recycler' : 'Hydrolyser →'}
        </button>
        
        <div 
          onClick={() => setIsHydrolyzed(true)}
          className={`cursor-pointer p-4 rounded-xl transition-all ${isHydrolyzed ? 'bg-gradient-to-br from-orange-500 to-red-500 text-white scale-110 shadow-lg' : 'bg-white text-slate-600 border border-slate-200'}`}
        >
          <div className="text-center">
            <div className="text-2xl mb-1">⚡</div>
            <div className="font-bold">ADP + P</div>
            <div className="text-xs opacity-80">+ 7,3 Kcal</div>
          </div>
        </div>
      </div>
      <p className="text-center text-sm text-amber-700 mt-4">
        {isHydrolyzed 
          ? "✨ Énergie libérée pour la cellule ! Le cycle recommencera dans la mitochondrie."
          : "👆 Cliquez pour simuler l'hydrolyse de l'ATP"
        }
      </p>
    </div>
  );
}

// Mitochondria Diagram
function MitochondriaDiagram() {
  const [showInputs, setShowInputs] = useState(true);
  const [showOutputs, setShowOutputs] = useState(true);

  return (
    <div className="bg-gradient-to-br from-pink-50 to-purple-50 rounded-xl p-6 border border-purple-200">
      <h4 className="text-lg font-bold text-purple-800 mb-4 text-center">🔬 La Machine Mitochondriale</h4>
      
      <div className="relative">
        {/* Mitochondria shape */}
        <div className="mx-auto w-64 h-40 bg-gradient-to-br from-pink-400 to-purple-500 rounded-full relative shadow-xl">
          {/* Inner membrane folds */}
          <div className="absolute inset-4 border-4 border-white/30 rounded-full">
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white font-bold text-center">
              <div className="text-2xl">⚡</div>
              <div className="text-sm">ATP</div>
            </div>
          </div>
          {/* Cristae */}
          <div className="absolute left-8 top-1/2 transform -translate-y-1/2 w-8 border-l-4 border-white/40 h-16 rounded-l-full"></div>
          <div className="absolute left-12 top-1/2 transform -translate-y-1/2 w-6 border-l-4 border-white/40 h-12 rounded-l-full"></div>
          <div className="absolute right-8 top-1/2 transform -translate-y-1/2 w-8 border-r-4 border-white/40 h-16 rounded-r-full"></div>
          <div className="absolute right-12 top-1/2 transform -translate-y-1/2 w-6 border-r-4 border-white/40 h-12 rounded-r-full"></div>
        </div>

        {/* Inputs */}
        <div className={`absolute left-0 top-1/2 transform -translate-y-1/2 -translate-x-full transition-all ${showInputs ? 'opacity-100' : 'opacity-30'}`}>
          <div className="flex flex-col gap-2 items-end pr-4">
            <div className="bg-blue-100 px-3 py-1 rounded-lg text-blue-700 font-medium text-sm">O₂</div>
            <div className="bg-green-100 px-3 py-1 rounded-lg text-green-700 font-medium text-sm">Glucose</div>
          </div>
          <div className="text-right pr-4 mt-2">
            <span className="text-2xl">→</span>
          </div>
        </div>

        {/* Outputs */}
        <div className={`absolute right-0 top-1/2 transform -translate-y-1/2 translate-x-full transition-all ${showOutputs ? 'opacity-100' : 'opacity-30'}`}>
          <div className="flex flex-col gap-2 items-start pl-4">
            <div className="bg-gray-100 px-3 py-1 rounded-lg text-gray-700 font-medium text-sm">CO₂</div>
            <div className="bg-blue-50 px-3 py-1 rounded-lg text-blue-600 font-medium text-sm">H₂O</div>
            <div className="bg-amber-100 px-3 py-1 rounded-lg text-amber-700 font-medium text-sm">ATP ⚡</div>
          </div>
        </div>
      </div>

      <div className="flex justify-center gap-4 mt-6">
        <button 
          onClick={() => setShowInputs(!showInputs)}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${showInputs ? 'bg-blue-500 text-white' : 'bg-slate-200 text-slate-600'}`}
        >
          Entrées {showInputs ? '✓' : ''}
        </button>
        <button 
          onClick={() => setShowOutputs(!showOutputs)}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${showOutputs ? 'bg-purple-500 text-white' : 'bg-slate-200 text-slate-600'}`}
        >
          Sorties {showOutputs ? '✓' : ''}
        </button>
      </div>

      <div className="mt-4 p-3 bg-white/50 rounded-lg">
        <p className="text-sm text-purple-700 text-center font-mono">
          Glucose + O₂ → CO₂ + H₂O + ATP
        </p>
      </div>
    </div>
  );
}

// Compartment Diagram
function CompartmentDiagram() {
  const [activeCompartment, setActiveCompartment] = useState<string | null>(null);

  return (
    <div className="bg-gradient-to-br from-cyan-50 to-blue-50 rounded-xl p-6 border border-blue-200">
      <h4 className="text-lg font-bold text-blue-800 mb-4 text-center">🩸 Les Compartiments Liquidiens</h4>
      
      <div className="relative h-64">
        {/* Capillaire sanguin */}
        <div 
          className={`absolute left-4 top-4 w-32 h-56 rounded-xl border-4 cursor-pointer transition-all ${
            activeCompartment === 'sang' ? 'bg-red-200 border-red-500 scale-105' : 'bg-red-100 border-red-300'
          }`}
          onClick={() => setActiveCompartment(activeCompartment === 'sang' ? null : 'sang')}
        >
          <div className="text-center pt-4">
            <div className="text-2xl">🩸</div>
            <div className="font-bold text-red-700 text-sm">Capillaire</div>
            <div className="font-bold text-red-700 text-sm">sanguin</div>
            <div className="text-xs text-red-600 mt-2">Plasma</div>
          </div>
          {/* Arrows */}
          <div className="absolute right-0 top-1/2 transform translate-x-full -translate-y-1/2">
            <span className="text-red-500 text-2xl">→</span>
          </div>
        </div>

        {/* Lymphe interstitielle */}
        <div 
          className={`absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 w-28 h-28 rounded-full border-4 cursor-pointer transition-all ${
            activeCompartment === 'lymphe' ? 'bg-yellow-200 border-yellow-500 scale-110' : 'bg-yellow-100 border-yellow-300'
          }`}
          onClick={() => setActiveCompartment(activeCompartment === 'lymphe' ? null : 'lymphe')}
        >
          <div className="text-center pt-4">
            <div className="text-xl">💧</div>
            <div className="font-bold text-yellow-700 text-xs">Lymphe</div>
            <div className="font-bold text-yellow-700 text-xs">interstitielle</div>
          </div>
        </div>

        {/* Cellule */}
        <div 
          className={`absolute right-4 top-1/2 transform -translate-y-1/2 w-32 h-32 rounded-2xl border-4 cursor-pointer transition-all ${
            activeCompartment === 'cellule' ? 'bg-green-200 border-green-500 scale-105' : 'bg-green-100 border-green-300'
          }`}
          onClick={() => setActiveCompartment(activeCompartment === 'cellule' ? null : 'cellule')}
        >
          <div className="text-center pt-4">
            <div className="text-2xl">🧬</div>
            <div className="font-bold text-green-700">Cellule</div>
            <div className="text-xs text-green-600 mt-1">Milieu intracellulaire</div>
          </div>
        </div>

        {/* Capillaire lymphatique */}
        <div 
          className={`absolute right-4 bottom-4 w-24 h-24 rounded-xl border-4 cursor-pointer transition-all ${
            activeCompartment === 'lymphatique' ? 'bg-purple-200 border-purple-500 scale-105' : 'bg-purple-100 border-purple-300'
          }`}
          onClick={() => setActiveCompartment(activeCompartment === 'lymphatique' ? null : 'lymphatique')}
        >
          <div className="text-center pt-2">
            <div className="text-xl">💜</div>
            <div className="font-bold text-purple-700 text-xs">Capillaire</div>
            <div className="font-bold text-purple-700 text-xs">lymphatique</div>
          </div>
        </div>
      </div>

      {activeCompartment && (
        <div className="mt-4 p-4 bg-white rounded-xl shadow">
          {activeCompartment === 'sang' && (
            <p className="text-sm text-red-700">🩸 <strong>Capillaire sanguin :</strong> Le plasma transporte les nutriments (glucose, acides aminés, lipides) vers les cellules et évacue le CO₂.</p>
          )}
          {activeCompartment === 'lymphe' && (
            <p className="text-sm text-yellow-700">💧 <strong>Lymphe interstitielle :</strong> Fluide qui baigne les cellules, issu du plasma qui traverse les parois des capillaires.</p>
          )}
          {activeCompartment === 'cellule' && (
            <p className="text-sm text-green-700">🧬 <strong>Cellule :</strong> Utilise les nutriments pour la respiration (ATP) et la biosynthèse. Produit du CO₂ et de l'urée comme déchets.</p>
          )}
          {activeCompartment === 'lymphatique' && (
            <p className="text-sm text-purple-700">💜 <strong>Capillaire lymphatique :</strong> Récupère l'excès de lymphe et les protéines pour les ramener dans le sang.</p>
          )}
        </div>
      )}

      <MiniQuiz quizData={miniQuizzes.lymphe} />
    </div>
  );
}

// Comparison Table Exercise
function ComparisonTable() {
  const [answers, setAnswers] = useState<{[key: string]: boolean | null}>({
    glucose: null,
    proteines: null,
    uree: null,
    creatinine: null
  });
  const [showResults, setShowResults] = useState(false);

  const correctAnswers = {
    glucose: { plasma: true, urine: false },
    proteines: { plasma: true, urine: false },
    uree: { plasma: true, urine: true },
    creatinine: { plasma: true, urine: true }
  };

  const handleAnswer = (substance: string, fluid: 'plasma' | 'urine', value: boolean) => {
    if (showResults) return;
    setAnswers({ ...answers, [`${substance}-${fluid}`]: value });
  };

  return (
    <div className="bg-white rounded-xl p-6 border border-slate-200">
      <h4 className="text-lg font-bold text-slate-800 mb-4">📊 Comparaison Plasma vs Urine</h4>
      <p className="text-sm text-slate-600 mb-4">Cochez les cases où la substance est présente en temps normal :</p>
      
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="bg-violet-100">
              <th className="p-3 text-left text-violet-800">Substance</th>
              <th className="p-3 text-center text-violet-800">Plasma</th>
              <th className="p-3 text-center text-violet-800">Urine</th>
            </tr>
          </thead>
          <tbody>
            {['Glucose', 'Protéines', 'Urée', 'Créatinine'].map((substance) => (
              <tr key={substance} className="border-b">
                <td className="p-3 font-medium">{substance}</td>
                {['plasma', 'urine'].map((fluid) => (
                  <td key={fluid} className="p-3 text-center">
                    <input
                      type="checkbox"
                      checked={answers[`${substance.toLowerCase()}-${fluid}`] || false}
                      onChange={() => handleAnswer(substance.toLowerCase(), fluid as 'plasma' | 'urine', !answers[`${substance.toLowerCase()}-${fluid}`])}
                      disabled={showResults}
                      className={`w-5 h-5 rounded ${
                        showResults
                          ? answers[`${substance.toLowerCase()}-${fluid}`] === correctAnswers[substance.toLowerCase() as keyof typeof correctAnswers][fluid as 'plasma' | 'urine']
                            ? 'accent-green-500'
                            : 'accent-red-500'
                          : 'accent-violet-500'
                      }`}
                    />
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {!showResults ? (
        <button
          onClick={() => setShowResults(true)}
          className="mt-4 px-6 py-2 bg-violet-500 text-white rounded-lg font-medium hover:bg-violet-600 transition-all"
        >
          Vérifier
        </button>
      ) : (
        <div className="mt-4 p-4 bg-indigo-50 rounded-lg">
          <p className="text-sm text-indigo-700">
            💡 <strong>Correction :</strong> En temps normal, le glucose et les protéines sont réabsorbés par les reins. 
            Seuls les déchets azotés (urée, créatinine) passent dans l'urine.
          </p>
          <button
            onClick={() => {
              setShowResults(false);
              setAnswers({ glucose: null, proteines: null, uree: null, creatinine: null });
            }}
            className="mt-3 text-sm text-violet-600 hover:text-violet-800 font-medium"
          >
            Réessayer ↺
          </button>
        </div>
      )}
    </div>
  );
}

// Main App Component
export default function App() {
  const [activeSection, setActiveSection] = useState('resume');
  const [expandedNode, setExpandedNode] = useState<string | null>(null);
  const [flippedCards, setFlippedCards] = useState<boolean[]>(new Array(flashcards.length).fill(false));

  const toggleCard = (index: number) => {
    const newFlipped = [...flippedCards];
    newFlipped[index] = !newFlipped[index];
    setFlippedCards(newFlipped);
  };

  const sections = [
    { id: 'acquis', label: '📚 Acquis', icon: '📚' },
    { id: 'resume', label: '🧠 Résumé', icon: '🧠' },
    { id: 'activites', label: '🧪 Activités', icon: '🧪' },
    { id: 'bilan', label: '📋 Bilan', icon: '📋' },
    { id: 'flashcards', label: '🃏 Flashcards', icon: '🃏' },
    { id: 'qcm', label: '✏️ QCM', icon: '✏️' },
    { id: 'exercices', label: '📝 Exercices', icon: '📝' },
  ];

  const resumeNodes = [
    { id: 'milieu', icon: '💧', title: 'Le Milieu Intérieur', subtitle: 'Le pont sang-cellule', color: 'from-cyan-500 to-blue-500' },
    { id: 'respiration', icon: '🔥', title: 'La Respiration', subtitle: 'Transformer le glucose en ATP', color: 'from-orange-500 to-red-500' },
    { id: 'biosynthese', icon: '🏗️', title: 'La Biosynthèse', subtitle: 'Construire la matière vivante', color: 'from-green-500 to-emerald-500' },
    { id: 'excretion', icon: '🧹', title: "L'Excrétion", subtitle: "Nettoyer l'usine cellulaire", color: 'from-purple-500 to-pink-500' },
    { id: 'liens', icon: '🔗', title: 'Liens transversaux', subtitle: 'Sport, Alimentation, Santé', color: 'from-violet-500 to-indigo-500' },
  ];

  const resumeContent: {[key: string]: { title: string; content: string[]; key?: string[] }} = {
    milieu: {
      title: "💧 Le Milieu Intérieur",
      content: [
        "Le milieu intérieur comprend le plasma sanguin et la lymphe (canalisée + interstitielle).",
        "Il baigne toutes les cellules de l'organisme.",
        "Les capillaires sanguins permettent les échanges de nutriments (oses, lipides, acides aminés) et de déchets.",
        "La lymphe interstitielle provient du plasma qui traverse les parois des capillaires."
      ],
      key: ["Plasma + Lymphe = Milieu intérieur", "Échanges via les capillaires", "Nutriments → Cellules", "Déchets → Sang"]
    },
    respiration: {
      title: "🔥 La Respiration Cellulaire",
      content: [
        "La mitochondrie est le siège de la respiration cellulaire.",
        "Glucose + O₂ → CO₂ + H₂O + ATP",
        "L'ATP (Adénosine Triphosphate) est la source immédiate d'énergie pour la cellule.",
        "Hydrolyse : ATP + H₂O → ADP + P + 7,3 Kcal"
      ],
      key: ["Mitochondrie = usine énergétique", "ATP = monnaie énergétique", "Rendement ~40%", "Le reste → chaleur"]
    },
    biosynthese: {
      title: "🏗️ La Biosynthèse",
      content: [
        "Formation de molécules complexes à partir de molécules simples.",
        "Glycogène : stockage glucidique (foie/muscles)",
        "Triglycérides : stockage lipidique (tissu adipeux)",
        "Protéines : ex. insuline, enzymes"
      ],
      key: ["Glucose → Glycogène", "Acides gras → Triglycérides", "Acides aminés → Protéines", "Anabolisme"]
    },
    excretion: {
      title: "🧹 L'Excrétion",
      content: [
        "Élimination des déchets du métabolisme.",
        "Déchets azotés (urée, acide urique, créatinine) → Reins → Urine",
        "CO₂ → Poumons → Expiration",
        "Comparaison plasma vs urine : pas de glucose/protéines dans l'urine normale"
      ],
      key: ["Reins → Urée", "Poumons → CO₂", "Épuration du sang", "Homeostasie"]
    },
    liens: {
      title: "🔗 Liens Transversaux",
      content: [
        "Sport : ↑ débit sanguin → + glucose + O₂ → + ATP pour les muscles",
        "Analogie de l'usine : nutriments = bois, ATP = énergie, déchets = sciure",
        "Surpoids = trop de stockage (biosynthèse) sans assez de dégradation",
        "Diabète = problème de glucose → impact sur le métabolisme"
      ],
      key: ["Effort physique = + ATP", "Équilibre stockage/dégradation", "Santé métabolique", "Nutrition"]
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-50 via-indigo-50 to-blue-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-violet-600 via-indigo-600 to-blue-600 text-white py-8 px-4 shadow-xl">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center text-3xl backdrop-blur">
              🔬
            </div>
            <div>
              <h1 className="text-3xl font-bold">Chapitre 5 : Métabolisme Cellulaire</h1>
              <p className="text-violet-200">Thème 1 — p.150–167</p>
            </div>
          </div>
          <p className="text-lg text-violet-100 max-w-3xl">
            Comprendre les échanges entre le sang et les cellules, la production d'énergie, 
            l'élimination des déchets et la synthèse de nouvelles molécules.
          </p>
          
          {/* Questions directrices */}
          <div className="mt-6 grid md:grid-cols-2 gap-3">
            {[
              "Comment s'échangent les nutriments entre sang, lymphe et cellule ?",
              "Comment l'énergie est-elle produite à partir des nutriments ?",
              "Comment les déchets de la respiration sont-ils éliminés ?",
              "Comment les cellules synthétisent-elles de nouvelles molécules ?"
            ].map((q, i) => (
              <div key={i} className="bg-white/10 backdrop-blur rounded-lg p-3 text-sm">
                <span className="text-violet-300 font-bold">Q{i + 1}.</span> {q}
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur shadow-md">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex overflow-x-auto gap-1 py-2">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => setActiveSection(section.id)}
                className={`px-4 py-2 rounded-xl font-medium whitespace-nowrap transition-all ${
                  activeSection === section.id
                    ? 'bg-gradient-to-r from-violet-500 to-indigo-600 text-white shadow-lg'
                    : 'text-slate-600 hover:bg-violet-50'
                }`}
              >
                {section.label}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        
        {/* Acquis Section */}
        {activeSection === 'acquis' && (
          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-violet-800 flex items-center gap-3">
              📚 Prérequis — Ce que vous devez déjà connaître
            </h2>
            <div className="grid md:grid-cols-3 gap-4">
              {[
                { chapter: "Chapitre 2", title: "Appareil Digestif", icon: "🫁", items: ["Digestion mécanique et chimique", "Absorption intestinale", "Nutriments : glucose, acides aminés, lipides"] },
                { chapter: "Chapitre 3", title: "Appareil Circulatoire", icon: "🫀", items: ["Circulation sanguine", "Composition du sang", "Plasma et cellules sanguines"] },
                { chapter: "Chapitre 4", title: "Appareil Respiratoire", icon: "🫁", items: ["Échanges gazeux alvéolaires", "Oxygène et dioxyde de carbone", "Hémoglobine"] }
              ].map((ch) => (
                <div key={ch.chapter} className="bg-white rounded-xl p-6 shadow-lg border border-violet-100">
                  <div className="text-4xl mb-3">{ch.icon}</div>
                  <h3 className="font-bold text-violet-700">{ch.chapter}</h3>
                  <p className="text-slate-600 font-medium mb-3">{ch.title}</p>
                  <ul className="space-y-2">
                    {ch.items.map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-slate-600">
                        <span className="text-violet-500">•</span> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Résumé Section */}
        {activeSection === 'resume' && (
          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-violet-800 flex items-center gap-3">
              🧠 Résumé — Les 5 grandes notions
            </h2>
            <p className="text-slate-600">Cliquez sur chaque nœud pour approfondir :</p>
            
            <div className="grid md:grid-cols-5 gap-4">
              {resumeNodes.map((node) => (
                <button
                  key={node.id}
                  onClick={() => setExpandedNode(expandedNode === node.id ? null : node.id)}
                  className={`p-4 rounded-xl text-white transition-all transform hover:scale-105 bg-gradient-to-br ${node.color} ${
                    expandedNode === node.id ? 'ring-4 ring-violet-300 scale-105 shadow-xl' : 'shadow-lg'
                  }`}
                >
                  <div className="text-3xl mb-2">{node.icon}</div>
                  <h3 className="font-bold text-sm">{node.title}</h3>
                  <p className="text-xs opacity-90">{node.subtitle}</p>
                </button>
              ))}
            </div>

            {expandedNode && resumeContent[expandedNode] && (
              <div className="bg-white rounded-2xl p-6 shadow-xl border border-violet-100 animate-fade-in">
                <h3 className="text-xl font-bold text-violet-800 mb-4">{resumeContent[expandedNode].title}</h3>
                <ul className="space-y-3 mb-6">
                  {resumeContent[expandedNode].content.map((item, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <span className="text-violet-500 mt-1">✓</span>
                      <span className="text-slate-700">{item}</span>
                    </li>
                  ))}
                </ul>
                {resumeContent[expandedNode].key && (
                  <div className="bg-violet-50 rounded-xl p-4">
                    <h4 className="font-bold text-violet-700 mb-2">🔑 Points clés à retenir :</h4>
                    <div className="flex flex-wrap gap-2">
                      {resumeContent[expandedNode].key.map((k, i) => (
                        <span key={i} className="px-3 py-1 bg-violet-200 text-violet-800 rounded-full text-sm font-medium">
                          {k}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </section>
        )}

        {/* Activités Section */}
        {activeSection === 'activites' && (
          <section className="space-y-8">
            <h2 className="text-2xl font-bold text-violet-800 flex items-center gap-3">
              🧪 Activités — Échanges et Respiration
            </h2>

            {/* Partie 1: Les compartiments */}
            <div className="bg-white rounded-2xl p-6 shadow-xl border border-violet-100">
              <h3 className="text-xl font-bold text-indigo-700 mb-4">1. Les Compartiments Liquidiens</h3>
              <CompartmentDiagram />
            </div>

            {/* Partie 2: La machine mitochondriale */}
            <div className="bg-white rounded-2xl p-6 shadow-xl border border-violet-100">
              <h3 className="text-xl font-bold text-indigo-700 mb-4">2. La Machine Mitochondriale</h3>
              <MitochondriaDiagram />
              <div className="mt-6">
                <MiniQuiz quizData={miniQuizzes.mitochondrie} />
              </div>
            </div>

            {/* Partie 3: Le cycle de l'ATP */}
            <div className="bg-white rounded-2xl p-6 shadow-xl border border-violet-100">
              <h3 className="text-xl font-bold text-indigo-700 mb-4">3. Le Cycle de l'ATP</h3>
              <ATPCycle />
            </div>
          </section>
        )}

        {/* Bilan Section */}
        {activeSection === 'bilan' && (
          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-violet-800 flex items-center gap-3">
              📋 Bilan — Synthèse des 4 points essentiels
            </h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              {[
                { num: 1, title: "Milieu intérieur", desc: "Le milieu intérieur (plasma + lymphe) baigne les cellules.", icon: "💧", color: "from-cyan-500 to-blue-500" },
                { num: 2, title: "Respiration cellulaire", desc: "La respiration cellulaire dégrade les nutriments pour produire de l'ATP.", icon: "⚡", color: "from-orange-500 to-red-500" },
                { num: 3, title: "Excrétion", desc: "L'excrétion rénale et pulmonaire assure l'épuration du sang.", icon: "🧹", color: "from-purple-500 to-pink-500" },
                { num: 4, title: "Biosynthèse", desc: "La biosynthèse permet le renouvellement et le stockage de l'énergie.", icon: "🏗️", color: "from-green-500 to-emerald-500" }
              ].map((point) => (
                <div key={point.num} className={`bg-gradient-to-br ${point.color} rounded-2xl p-6 text-white shadow-xl`}>
                  <div className="flex items-center gap-4 mb-3">
                    <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl">
                      {point.icon}
                    </div>
                    <div>
                      <span className="text-sm opacity-80">Point {point.num}</span>
                      <h3 className="font-bold text-lg">{point.title}</h3>
                    </div>
                  </div>
                  <p className="text-white/90">{point.desc}</p>
                </div>
              ))}
            </div>

            {/* Schéma de synthèse */}
            <div className="bg-white rounded-2xl p-6 shadow-xl border border-violet-100">
              <h3 className="text-xl font-bold text-indigo-700 mb-6 text-center">🔗 Synthèse : Fonctions Bâtisseur vs Énergétique</h3>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-200">
                  <h4 className="font-bold text-green-700 text-lg mb-3">🏗️ Fonction Bâtisseur</h4>
                  <p className="text-green-600 mb-3">Biosynthèse (Anabolisme)</p>
                  <ul className="space-y-2 text-sm text-slate-700">
                    <li>• Glucose → Glycogène</li>
                    <li>• Acides gras → Triglycérides</li>
                    <li>• Acides aminés → Protéines</li>
                  </ul>
                  <p className="mt-3 text-sm text-green-700 font-medium">↑ Consomme de l'ATP</p>
                </div>
                <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-6 border border-orange-200">
                  <h4 className="font-bold text-orange-700 text-lg mb-3">🔥 Fonction Énergétique</h4>
                  <p className="text-orange-600 mb-3">Respiration (Catabolisme)</p>
                  <ul className="space-y-2 text-sm text-slate-700">
                    <li>• Glucose + O₂ → CO₂ + H₂O</li>
                    <li>• Production d'ATP</li>
                    <li>• Libération de chaleur</li>
                  </ul>
                  <p className="mt-3 text-sm text-orange-700 font-medium">↓ Produit de l'ATP</p>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Flashcards Section */}
        {activeSection === 'flashcards' && (
          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-violet-800 flex items-center gap-3">
              🃏 Flashcards — 8 termes à maîtriser
            </h2>
            <p className="text-slate-600">Cliquez sur une carte pour retourner et voir la définition :</p>
            
            <div className="grid md:grid-cols-4 gap-4">
              {flashcards.map((card, index) => (
                <FlashcardItem
                  key={index}
                  card={card}
                  isFlipped={flippedCards[index]}
                  onClick={() => toggleCard(index)}
                />
              ))}
            </div>
            
            <div className="flex gap-4 justify-center">
              <button
                onClick={() => setFlippedCards(new Array(flashcards.length).fill(true))}
                className="px-6 py-2 bg-violet-500 text-white rounded-xl font-medium hover:bg-violet-600 transition-all"
              >
                Tout retourner
              </button>
              <button
                onClick={() => setFlippedCards(new Array(flashcards.length).fill(false))}
                className="px-6 py-2 bg-slate-200 text-slate-700 rounded-xl font-medium hover:bg-slate-300 transition-all"
              >
                Tout remettre
              </button>
            </div>
          </section>
        )}

        {/* QCM Section */}
        {activeSection === 'qcm' && (
          <section className="space-y-6">
            <h2 className="text-2xl font-bold text-violet-800 flex items-center gap-3">
              ✏️ QCM — 10 questions sur le métabolisme
            </h2>
            <QCMSection questions={qcmQuestions} />
          </section>
        )}

        {/* Exercices Section */}
        {activeSection === 'exercices' && (
          <section className="space-y-8">
            <h2 className="text-2xl font-bold text-violet-800 flex items-center gap-3">
              📝 Exercices d'application
            </h2>

            {/* Exercice 1: Schéma fléché */}
            <div className="bg-white rounded-2xl p-6 shadow-xl border border-violet-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-violet-100 rounded-xl flex items-center justify-center text-xl">1</div>
                <h3 className="text-xl font-bold text-indigo-700">Schéma des Compartiments Liquidiens</h3>
              </div>
              <p className="text-slate-600 mb-4">Indiquez le sens de déplacement des nutriments et déchets entre les compartiments :</p>
              <CompartmentDiagram />
            </div>

            {/* Exercice 2: Expérience sur les levures */}
            <div className="bg-white rounded-2xl p-6 shadow-xl border border-violet-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-violet-100 rounded-xl flex items-center justify-center text-xl">2</div>
                <h3 className="text-xl font-bold text-indigo-700">Expérience sur les Levures</h3>
              </div>
              <p className="text-slate-600 mb-4">Interprétez la chute d'O₂ après injection de glucose chez les levures :</p>
              
              <div className="bg-gradient-to-br from-amber-50 to-yellow-50 rounded-xl p-6 border border-amber-200">
                <div className="mb-4">
                  <h4 className="font-bold text-amber-800 mb-2">🔬 Protocole expérimental</h4>
                  <ul className="space-y-2 text-sm text-slate-700">
                    <li>1. Des levures sont placées dans une solution nutritive</li>
                    <li>2. On mesure la concentration en O₂ en continu</li>
                    <li>3. À t=5 min, on injecte du glucose</li>
                    <li>4. On observe une chute rapide de O₂</li>
                  </ul>
                </div>
                
                <div className="bg-white rounded-lg p-4 mb-4">
                  <h4 className="font-bold text-slate-700 mb-2">📉 Graphique simplifié</h4>
                  <div className="flex items-end h-32 gap-1">
                    <div className="flex-1 bg-blue-400 h-full rounded-t"></div>
                    <div className="flex-1 bg-blue-400 h-4/5 rounded-t"></div>
                    <div className="flex-1 bg-blue-400 h-3/4 rounded-t"></div>
                    <div className="flex-1 bg-blue-400 h-2/3 rounded-t"></div>
                    <div className="flex-1 bg-red-400 h-1/3 rounded-t animate-pulse"></div>
                    <div className="flex-1 bg-red-400 h-1/4 rounded-t"></div>
                    <div className="flex-1 bg-red-400 h-1/5 rounded-t"></div>
                    <div className="flex-1 bg-red-400 h-1/6 rounded-t"></div>
                  </div>
                  <div className="flex justify-between text-xs text-slate-500 mt-1">
                    <span>0</span>
                    <span>5 min (injection glucose)</span>
                    <span>10 min</span>
                  </div>
                </div>

                <div className="bg-green-100 rounded-lg p-4">
                  <h4 className="font-bold text-green-800 mb-2">💡 Explication</h4>
                  <p className="text-sm text-green-700">
                    L'injection de glucose déclenche la <strong>respiration cellulaire</strong> dans les levures. 
                    Celles-ci consomment l'O₂ pour oxyder le glucose et produire de l'ATP, d'où la chute de O₂ mesurée.
                  </p>
                </div>
              </div>
            </div>

            {/* Exercice 3: Tableau comparatif */}
            <div className="bg-white rounded-2xl p-6 shadow-xl border border-violet-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-violet-100 rounded-xl flex items-center justify-center text-xl">3</div>
                <h3 className="text-xl font-bold text-indigo-700">Comparaison Plasma vs Urine</h3>
              </div>
              <p className="text-slate-600 mb-4">Différenciez plasma et urine (absence de glucose/protéines en cas normal) :</p>
              <ComparisonTable />
            </div>
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-violet-600 via-indigo-600 to-blue-600 text-white py-6 px-4 mt-12">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-violet-200">
            📚 Fiche interactive — Chapitre 5 : Métabolisme Cellulaire
          </p>
          <p className="text-sm text-violet-300 mt-2">
            Palette violet/bleu métabolisme 🎨
          </p>
        </div>
      </footer>

      <style>{`
        .perspective-1000 {
          perspective: 1000px;
        }
        .transform-style-preserve-3d {
          transform-style: preserve-3d;
        }
        .backface-hidden {
          backface-visibility: hidden;
        }
        .rotate-y-180 {
          transform: rotateY(180deg);
        }
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}